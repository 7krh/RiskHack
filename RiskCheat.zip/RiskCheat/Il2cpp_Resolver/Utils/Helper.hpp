#pragma once
#include <Unity/Includes.hpp>

namespace IL2CPP
{
	namespace Helper
	{
		Unity::CComponent* GetMonoBehaviour();
	}
}