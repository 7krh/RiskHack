#pragma once

Unity::CGameObject* LocalPlayer = NULL;
std::vector<Unity::CGameObject*> PlayerList(NULL);